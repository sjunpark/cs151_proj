

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.JButton;
import javax.swing.JPanel;


public class Buttons extends JPanel implements ActionListener {
	private JButton 			previousMonthBtn;
	private JButton				nextMonthBtn;
	private JButton				createBtn;
	private JButton 			quitBtn;	
//	private JButton				today;
	private GregorianCalendar 	cal;
	private MyCalendar			mc;
	
	public Buttons(MyCalendar myc) {		
		this.mc = myc;
		cal = mc.getCalendar();
		
//		today = new JButton("Today");
		previousMonthBtn = new JButton("<");
		nextMonthBtn = new JButton(">");
		createBtn = new JButton("CREATE");
		quitBtn = new JButton("QUIT");
		
//		today.addActionListener(this);
		previousMonthBtn.addActionListener(this);
		nextMonthBtn.addActionListener(this);
		createBtn.addActionListener(this);
		quitBtn.addActionListener(this);
		
//		this.add(today);
		this.add(previousMonthBtn);
		this.add(nextMonthBtn);
		this.add(createBtn);
		this.add(quitBtn);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==previousMonthBtn){
			GregorianCalendar temp = cal;
			temp.add(Calendar.DATE,-1);
			mc.getCalendarController().changeDate(temp);
		}
		else if(e.getSource()==nextMonthBtn){
			GregorianCalendar temp = cal;
			temp.add(Calendar.DATE,1);
			mc.getCalendarController().changeDate(temp);
		}
		else if(e.getSource()==createBtn){
			Create c = new Create(mc.getEventSet());
			c.setVisible(true);
		}
		else if(e.getSource() == quitBtn)
			mc.closeProgram();
//		else if(e.getSource() == today){
//			GregorianCalendar c = new GregorianCalendar();
//			mc.getCalendarController().changeDate(c);
//		}
	}
}
