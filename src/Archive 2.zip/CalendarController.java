

import java.awt.BorderLayout;
import java.util.GregorianCalendar;

import javax.swing.JPanel;

public class CalendarController extends JPanel{
	private DayView day;
	private MonthView month;
	private MyCalendar mc;
	
	public CalendarController(MyCalendar myc) {
		this.mc = myc;
		
		month = new MonthView(mc);
		day = new DayView(mc.getCalendar(), mc.getEventSet());
		
		this.setLayout(new BorderLayout());
		this.add(month,BorderLayout.WEST);
		this.add(day,BorderLayout.EAST);
	}
	
	public void modify() {
		day.printDayView(mc.getCalendar());
	}
	
	public void changeDate(GregorianCalendar c) {
		month.printMonthlyCalendar(c);
		day.printDayView(c);
	}
}
