
public class SimpleCalendar {
	public static void main(String[]args) {
		MyCalendar mycal =new MyCalendar();
	}
}
